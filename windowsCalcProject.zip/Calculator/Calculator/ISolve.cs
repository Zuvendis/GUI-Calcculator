﻿using System;
public interface Isolve
{
    void Accumulate(string s);
    void Clear();
    double Solve();
}
 