namespace Calculator
{
    public partial class Form1 : Form
    {
        Solver calculator = new Solver();//solver object
        public Form1()
        {
            InitializeComponent();
        }

        private void One_Click(object sender, EventArgs e)
        {
            calculator.Accumulate("1");
            textBox1.Text += "1";
        }

        private void Two_Click(object sender, EventArgs e)
        {
            calculator.Accumulate("2");
            textBox1.Text += "2";
        }

        private void Three_Click(object sender, EventArgs e)
        {

            calculator.Accumulate("3");
            textBox1.Text += "3";
        }

        private void Four_Click(object sender, EventArgs e)
        {

            calculator.Accumulate("4");
            textBox1.Text += "4";
        }

        private void Five_Click(object sender, EventArgs e)
        {
            calculator.Accumulate("5");
            textBox1.Text += "5";
        }

        private void Six_Click(object sender, EventArgs e)
        {
            calculator.Accumulate("6");
            textBox1.Text += "6";
        }

        private void Seven_Click(object sender, EventArgs e)
        {
            calculator.Accumulate("7");
            textBox1.Text += "7";
        }

        private void Eight_Click(object sender, EventArgs e)
        {
            calculator.Accumulate("8");
            textBox1.Text += "8";
        }

        private void Nine_Click(object sender, EventArgs e)
        {
            calculator.Accumulate("9");
            textBox1.Text += "9";
        }

        private void Zero_Click(object sender, EventArgs e)
        {
            calculator.Accumulate("0");
            textBox1.Text += "0";
        }

        private void divide_Click(object sender, EventArgs e)//this is to divide two numbers
        {
            calculator.Accumulate("/");
            textBox1.Text += "/";
        }

        private void plus_Click(object sender, EventArgs e)//this is to add two numbers
        {
            calculator.Accumulate("+");
            textBox1.Text += "+";
        }

        private void minus_Click(object sender, EventArgs e)//this is to subtract two numbers
        {
            calculator.Accumulate("-");
            textBox1.Text += "-";
        }

        private void multiply_Click(object sender, EventArgs e)//this is to multiply two numbers
        {
            calculator.Accumulate("*");
            textBox1.Text += "*";
        }

        private void mod_Click(object sender, EventArgs e)//this is used to solve for the modulus
        {
            calculator.Accumulate("%");
            textBox1.Text += "%";
        }

        private void point_Click(object sender, EventArgs e)//this is used to indicate decimals
        {
            calculator.Accumulate(".");
            textBox1.Text += ".";
        }

        private void button8_Click(object sender, EventArgs e)//this is to indicate that a number is negative
        {
            calculator.Accumulate("-");
            textBox1.Text += "-";
        }

        private void clear_Click(object sender, EventArgs e)//this is to clear the calculator screen after a solution
        {
            calculator.Clear();
            textBox1.Text = "";
        }

        private void equal_Click(object sender, EventArgs e)
        {
           calculator.Solve();
            textBox1.Text = "box";
        }
    }
}