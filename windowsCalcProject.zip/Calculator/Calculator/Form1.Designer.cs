﻿namespace Calculator
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Zero = new System.Windows.Forms.Button();
            this.Seven = new System.Windows.Forms.Button();
            this.Eight = new System.Windows.Forms.Button();
            this.Five = new System.Windows.Forms.Button();
            this.Four = new System.Windows.Forms.Button();
            this.Two = new System.Windows.Forms.Button();
            this.One = new System.Windows.Forms.Button();
            this.change = new System.Windows.Forms.Button();
            this.clear = new System.Windows.Forms.Button();
            this.equal = new System.Windows.Forms.Button();
            this.point = new System.Windows.Forms.Button();
            this.multiply = new System.Windows.Forms.Button();
            this.Nine = new System.Windows.Forms.Button();
            this.minus = new System.Windows.Forms.Button();
            this.Six = new System.Windows.Forms.Button();
            this.plus = new System.Windows.Forms.Button();
            this.Three = new System.Windows.Forms.Button();
            this.divide = new System.Windows.Forms.Button();
            this.mod = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 36);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(776, 85);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = "--------------";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Zero
            // 
            this.Zero.Location = new System.Drawing.Point(54, 394);
            this.Zero.Name = "Zero";
            this.Zero.Size = new System.Drawing.Size(202, 29);
            this.Zero.TabIndex = 1;
            this.Zero.Text = "0";
            this.Zero.UseVisualStyleBackColor = true;
            this.Zero.Click += new System.EventHandler(this.Zero_Click);
            // 
            // Seven
            // 
            this.Seven.Location = new System.Drawing.Point(54, 337);
            this.Seven.Name = "Seven";
            this.Seven.Size = new System.Drawing.Size(64, 29);
            this.Seven.TabIndex = 2;
            this.Seven.Text = "7";
            this.Seven.UseVisualStyleBackColor = true;
            this.Seven.Click += new System.EventHandler(this.Seven_Click);
            // 
            // Eight
            // 
            this.Eight.Location = new System.Drawing.Point(162, 337);
            this.Eight.Name = "Eight";
            this.Eight.Size = new System.Drawing.Size(64, 29);
            this.Eight.TabIndex = 3;
            this.Eight.Text = "8";
            this.Eight.UseVisualStyleBackColor = true;
            this.Eight.Click += new System.EventHandler(this.Eight_Click);
            // 
            // Five
            // 
            this.Five.Location = new System.Drawing.Point(162, 284);
            this.Five.Name = "Five";
            this.Five.Size = new System.Drawing.Size(64, 29);
            this.Five.TabIndex = 5;
            this.Five.Text = "5";
            this.Five.UseVisualStyleBackColor = true;
            this.Five.Click += new System.EventHandler(this.Five_Click);
            // 
            // Four
            // 
            this.Four.Location = new System.Drawing.Point(54, 284);
            this.Four.Name = "Four";
            this.Four.Size = new System.Drawing.Size(64, 29);
            this.Four.TabIndex = 4;
            this.Four.Text = "4";
            this.Four.UseVisualStyleBackColor = true;
            this.Four.Click += new System.EventHandler(this.Four_Click);
            // 
            // Two
            // 
            this.Two.Location = new System.Drawing.Point(162, 229);
            this.Two.Name = "Two";
            this.Two.Size = new System.Drawing.Size(64, 29);
            this.Two.TabIndex = 7;
            this.Two.Text = "2";
            this.Two.UseVisualStyleBackColor = true;
            this.Two.Click += new System.EventHandler(this.Two_Click);
            // 
            // One
            // 
            this.One.Location = new System.Drawing.Point(54, 229);
            this.One.Name = "One";
            this.One.Size = new System.Drawing.Size(64, 29);
            this.One.TabIndex = 6;
            this.One.Text = "1";
            this.One.UseVisualStyleBackColor = true;
            this.One.Click += new System.EventHandler(this.One_Click);
            // 
            // change
            // 
            this.change.Location = new System.Drawing.Point(162, 175);
            this.change.Name = "change";
            this.change.Size = new System.Drawing.Size(64, 29);
            this.change.TabIndex = 9;
            this.change.Text = "+/-";
            this.change.UseVisualStyleBackColor = true;
            this.change.Click += new System.EventHandler(this.button8_Click);
            // 
            // clear
            // 
            this.clear.Location = new System.Drawing.Point(54, 175);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(64, 29);
            this.clear.TabIndex = 8;
            this.clear.Text = "AC";
            this.clear.UseVisualStyleBackColor = true;
            this.clear.Click += new System.EventHandler(this.clear_Click);
            // 
            // equal
            // 
            this.equal.Location = new System.Drawing.Point(398, 394);
            this.equal.Name = "equal";
            this.equal.Size = new System.Drawing.Size(64, 29);
            this.equal.TabIndex = 11;
            this.equal.Text = "=";
            this.equal.UseVisualStyleBackColor = true;
            this.equal.Click += new System.EventHandler(this.equal_Click);
            // 
            // point
            // 
            this.point.Location = new System.Drawing.Point(290, 394);
            this.point.Name = "point";
            this.point.Size = new System.Drawing.Size(64, 29);
            this.point.TabIndex = 10;
            this.point.Text = ".";
            this.point.UseVisualStyleBackColor = true;
            this.point.Click += new System.EventHandler(this.point_Click);
            // 
            // multiply
            // 
            this.multiply.Location = new System.Drawing.Point(398, 337);
            this.multiply.Name = "multiply";
            this.multiply.Size = new System.Drawing.Size(64, 29);
            this.multiply.TabIndex = 13;
            this.multiply.Text = "X";
            this.multiply.UseVisualStyleBackColor = true;
            this.multiply.Click += new System.EventHandler(this.multiply_Click);
            // 
            // Nine
            // 
            this.Nine.Location = new System.Drawing.Point(290, 337);
            this.Nine.Name = "Nine";
            this.Nine.Size = new System.Drawing.Size(64, 29);
            this.Nine.TabIndex = 12;
            this.Nine.Text = "9";
            this.Nine.UseVisualStyleBackColor = true;
            this.Nine.Click += new System.EventHandler(this.Nine_Click);
            // 
            // minus
            // 
            this.minus.Location = new System.Drawing.Point(398, 284);
            this.minus.Name = "minus";
            this.minus.Size = new System.Drawing.Size(64, 29);
            this.minus.TabIndex = 15;
            this.minus.Text = "-";
            this.minus.UseVisualStyleBackColor = true;
            this.minus.Click += new System.EventHandler(this.minus_Click);
            // 
            // Six
            // 
            this.Six.Location = new System.Drawing.Point(290, 284);
            this.Six.Name = "Six";
            this.Six.Size = new System.Drawing.Size(64, 29);
            this.Six.TabIndex = 14;
            this.Six.Text = "6";
            this.Six.UseVisualStyleBackColor = true;
            this.Six.Click += new System.EventHandler(this.Six_Click);
            // 
            // plus
            // 
            this.plus.Location = new System.Drawing.Point(398, 229);
            this.plus.Name = "plus";
            this.plus.Size = new System.Drawing.Size(64, 29);
            this.plus.TabIndex = 17;
            this.plus.Text = "+";
            this.plus.UseVisualStyleBackColor = true;
            this.plus.Click += new System.EventHandler(this.plus_Click);
            // 
            // Three
            // 
            this.Three.Location = new System.Drawing.Point(290, 229);
            this.Three.Name = "Three";
            this.Three.Size = new System.Drawing.Size(64, 29);
            this.Three.TabIndex = 16;
            this.Three.Text = "3";
            this.Three.UseVisualStyleBackColor = true;
            this.Three.Click += new System.EventHandler(this.Three_Click);
            // 
            // divide
            // 
            this.divide.Location = new System.Drawing.Point(398, 175);
            this.divide.Name = "divide";
            this.divide.Size = new System.Drawing.Size(64, 29);
            this.divide.TabIndex = 19;
            this.divide.Text = "/";
            this.divide.UseVisualStyleBackColor = true;
            this.divide.Click += new System.EventHandler(this.divide_Click);
            // 
            // mod
            // 
            this.mod.Location = new System.Drawing.Point(290, 175);
            this.mod.Name = "mod";
            this.mod.Size = new System.Drawing.Size(64, 29);
            this.mod.TabIndex = 18;
            this.mod.Text = "%";
            this.mod.UseVisualStyleBackColor = true;
            this.mod.Click += new System.EventHandler(this.mod_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.divide);
            this.Controls.Add(this.mod);
            this.Controls.Add(this.plus);
            this.Controls.Add(this.Three);
            this.Controls.Add(this.minus);
            this.Controls.Add(this.Six);
            this.Controls.Add(this.multiply);
            this.Controls.Add(this.Nine);
            this.Controls.Add(this.equal);
            this.Controls.Add(this.point);
            this.Controls.Add(this.change);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.Two);
            this.Controls.Add(this.One);
            this.Controls.Add(this.Five);
            this.Controls.Add(this.Four);
            this.Controls.Add(this.Eight);
            this.Controls.Add(this.Seven);
            this.Controls.Add(this.Zero);
            this.Controls.Add(this.textBox1);
            this.Name = "Form1";
            this.Text = "Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox textBox1;
        private Button Zero;
        private Button Seven;
        private Button Eight;
        private Button Five;
        private Button Four;
        private Button Two;
        private Button One;
        private Button change;
        private Button clear;
        private Button equal;
        private Button point;
        private Button multiply;
        private Button Nine;
        private Button minus;
        private Button Six;
        private Button plus;
        private Button Three;
        private Button divide;
        private Button mod;
    }
}