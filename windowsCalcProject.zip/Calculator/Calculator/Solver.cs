﻿


public class Solver: Isolve
{
    string box = "";//this keeps track of info that we input
    string ans = "";//this is tho hold 
    public void Accumulate(string s)
    {
        box += s;
    }
   public void Clear()
    {
        box = string.Empty;
    }
   public double Solve()
    {
        
        int holdL = 0;
        int holdR = 0;
        double result = 0.0;

        for (int i = 0; i < box.Length; i++)
        {
            if (box[i] == '*')
            {
                // Find left operand
                for (int j = i - 1; j >= 0; j--)
                {
                    if (box[j] == '/' || box[j] == '+' || box[j] == '-' || box[j] == '%')
                    {
                        holdL = j + 1;
                        break;
                    }
                    else if (j == 0)
                    {
                        holdL = 0;
                        break;
                    }
                }

                // Find right operand
                for (int j = i + 1; j < box.Length; j++)
                {
                    if (box[j] == '/' || box[j] == '+' || box[j] == '-' || box[j] == '%')
                    {
                        holdR = j - 1;
                        break;
                    }
                    else if (j == box.Length - 1)
                    {
                        holdR = j;
                        break;
                    }
                }

                // Compute result
                double leftOperand = Convert.ToDouble(box.Substring(holdL, i - holdL));
                double rightOperand = Convert.ToDouble(box.Substring(i + 1, holdR - i));
                result = leftOperand * rightOperand;

                // Replace operands and operator with result
                box = box.Substring(0, holdL) + result.ToString() + box.Substring(holdR + 1);
                i = holdL - 1; // Reset loop index to start from beginning of modified string
            }
            else if (box[i] == '/')
            {
                // Handle division operator
                // Similar logic as for multiplication operator
            }
            else if (box[i] == '+')
            {
                // Handle addition operator
                // Similar logic as for multiplication operator
            }
            else if (box[i] == '-')
            {
                // Handle subtraction operator
                // Similar logic as for multiplication operator
            }
            else if (box[i] == '%')
            {
                // Handle modulus operator
                // Similar logic as for multiplication operator
            }
        }

        return result;
        


        /*//multiplication before division
        //addition before subtraction
        int holdL;
        int holdR;

        for(int i=0; i <box.Length; i++)
        {
            //multiplication
            if (box[i] == '*')
            {
                for (int j = i - 1; j > 0; j--)// for the values before the multiplication symbol
                {
                    if (box[j] == '/' || box[j] == '+' || box[j] == '-' || box[j] == '%' || box[j] == '*')
                    {
                        holdL = j;
                        break;
                    }

                }
                for (int j = i + 1; j<box.Length; j++)//for the values after the multiplcation symbol
                {
                    if (box[j] == '/' || box[j] == '+' || box[j] == '-' || box[j] == '%' || box[j] == '*')
                    {
                        holdR = j;
                        break;
                    }

                   
                }

                string valueL = box.Substring(0, i);
                string valueR = box.Substring(i, box.Length());

                


            }

            //division
            if( box == "/")
            {
                for (int j = i - 1; j > 0; j--)// for the values before the multiplication symbol
                {
                    if (box[j] == '/' || box[j] == '+' || box[j] == '-' || box[j] == '%' || box[j] == '*')
                    {
                        holdL = j;
                        break;
                    }

                }
                for (int j = i + 1; j < box.Length; j++)//for the values after the multiplcation symbol
                {
                    if (box[j] == '/' || box[j] == '+' || box[j] == '-' || box[j] == '%' || box[j] == '*')
                    {
                        holdR = j;
                        break;
                    }


                }

                string valueL = box.Substring(0, i);
                string valueR = box.Substring(i, box.Length());


            }


            //addition
            if (box == "+")
            {
                for (int j = i - 1; j > 0; j--)// for the values before the multiplication symbol
                {
                    if (box[j] == '/' || box[j] == '+' || box[j] == '-' || box[j] == '%' || box[j] == '*')
                    {
                        holdL = j;
                        break;
                    }

                }
                for (int j = i + 1; j < box.Length; j++)//for the values after the multiplcation symbol
                {
                    if (box[j] == '/' || box[j] == '+' || box[j] == '-' || box[j] == '%' || box[j] == '*')
                    {
                        holdR = j;
                        break;
                    }


                }

                string valueL = box.Substring(holdL, i);
                string valueR = box.Substring(i, box.Length-i);


            }


            //subtraction
            if (box == "-")
            {
                for (int j = i - 1; j > 0; j--)// for the values before the multiplication symbol
                {
                    if (box[j] == '/' || box[j] == '+' || box[j] == '-' || box[j] == '%' || box[j] == '*')
                    {
                        holdL = j;
                        break;
                    }

                }
                for (int j = i + 1; j < box.Length; j++)//for the values after the multiplcation symbol
                {
                    if (box[j] == '/' || box[j] == '+' || box[j] == '-' || box[j] == '%' || box[j] == '*')
                    {
                        holdR = j;
                        break;
                    }


                }

                string valueL = box.Substring(0,i);
                string valueR = box.Substring(i,box.Length());


            }
        }



    }*/
    }
